﻿namespace KeyCommander
{
    partial class KeyCommander
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.startGame = new System.Windows.Forms.Button();
            this.Results = new System.Windows.Forms.Button();
            this.sqtime = new System.Windows.Forms.Timer(this.components);
            this.inputBox1 = new System.Windows.Forms.PictureBox();
            this.inputBox2 = new System.Windows.Forms.PictureBox();
            this.inputBox3 = new System.Windows.Forms.PictureBox();
            this.inputBox4 = new System.Windows.Forms.PictureBox();
            this.inputBox5 = new System.Windows.Forms.PictureBox();
            this.inputBox6 = new System.Windows.Forms.PictureBox();
            this.inputBox7 = new System.Windows.Forms.PictureBox();
            this.inputBox8 = new System.Windows.Forms.PictureBox();
            this.inputBox9 = new System.Windows.Forms.PictureBox();
            this.inputBox10 = new System.Windows.Forms.PictureBox();
            this.inputBox11 = new System.Windows.Forms.PictureBox();
            this.inputBox12 = new System.Windows.Forms.PictureBox();
            this.KeyCom = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.name_box = new System.Windows.Forms.TextBox();
            this.timer = new System.Windows.Forms.Label();
            this.points_lbl = new System.Windows.Forms.Label();
            this.Box12 = new System.Windows.Forms.PictureBox();
            this.Box11 = new System.Windows.Forms.PictureBox();
            this.Box10 = new System.Windows.Forms.PictureBox();
            this.Box9 = new System.Windows.Forms.PictureBox();
            this.Box8 = new System.Windows.Forms.PictureBox();
            this.Box7 = new System.Windows.Forms.PictureBox();
            this.Box6 = new System.Windows.Forms.PictureBox();
            this.Box5 = new System.Windows.Forms.PictureBox();
            this.Box4 = new System.Windows.Forms.PictureBox();
            this.Box3 = new System.Windows.Forms.PictureBox();
            this.Box2 = new System.Windows.Forms.PictureBox();
            this.Box1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box1)).BeginInit();
            this.SuspendLayout();
            // 
            // startGame
            // 
            this.startGame.Location = new System.Drawing.Point(301, 385);
            this.startGame.Name = "startGame";
            this.startGame.Size = new System.Drawing.Size(75, 23);
            this.startGame.TabIndex = 0;
            this.startGame.Text = "start";
            this.startGame.UseVisualStyleBackColor = true;
            this.startGame.Click += new System.EventHandler(this.startGame_Click);
            // 
            // Results
            // 
            this.Results.Location = new System.Drawing.Point(428, 385);
            this.Results.Name = "Results";
            this.Results.Size = new System.Drawing.Size(75, 23);
            this.Results.TabIndex = 1;
            this.Results.Text = "results";
            this.Results.UseVisualStyleBackColor = true;
            this.Results.Click += new System.EventHandler(this.Results_Click);
            // 
            // sqtime
            // 
            this.sqtime.Interval = 1000;
            this.sqtime.Tick += new System.EventHandler(this.Sqtimer);
            // 
            // inputBox1
            // 
            this.inputBox1.Location = new System.Drawing.Point(91, 259);
            this.inputBox1.Name = "inputBox1";
            this.inputBox1.Size = new System.Drawing.Size(43, 50);
            this.inputBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox1.TabIndex = 2;
            this.inputBox1.TabStop = false;
            // 
            // inputBox2
            // 
            this.inputBox2.Location = new System.Drawing.Point(140, 259);
            this.inputBox2.Name = "inputBox2";
            this.inputBox2.Size = new System.Drawing.Size(43, 50);
            this.inputBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox2.TabIndex = 3;
            this.inputBox2.TabStop = false;
            // 
            // inputBox3
            // 
            this.inputBox3.Location = new System.Drawing.Point(189, 259);
            this.inputBox3.Name = "inputBox3";
            this.inputBox3.Size = new System.Drawing.Size(43, 50);
            this.inputBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox3.TabIndex = 4;
            this.inputBox3.TabStop = false;
            // 
            // inputBox4
            // 
            this.inputBox4.Location = new System.Drawing.Point(238, 259);
            this.inputBox4.Name = "inputBox4";
            this.inputBox4.Size = new System.Drawing.Size(43, 50);
            this.inputBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox4.TabIndex = 5;
            this.inputBox4.TabStop = false;
            // 
            // inputBox5
            // 
            this.inputBox5.Location = new System.Drawing.Point(287, 259);
            this.inputBox5.Name = "inputBox5";
            this.inputBox5.Size = new System.Drawing.Size(43, 50);
            this.inputBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox5.TabIndex = 6;
            this.inputBox5.TabStop = false;
            // 
            // inputBox6
            // 
            this.inputBox6.Location = new System.Drawing.Point(336, 259);
            this.inputBox6.Name = "inputBox6";
            this.inputBox6.Size = new System.Drawing.Size(43, 50);
            this.inputBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox6.TabIndex = 7;
            this.inputBox6.TabStop = false;
            // 
            // inputBox7
            // 
            this.inputBox7.Location = new System.Drawing.Point(385, 259);
            this.inputBox7.Name = "inputBox7";
            this.inputBox7.Size = new System.Drawing.Size(43, 50);
            this.inputBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox7.TabIndex = 8;
            this.inputBox7.TabStop = false;
            // 
            // inputBox8
            // 
            this.inputBox8.Location = new System.Drawing.Point(439, 259);
            this.inputBox8.Name = "inputBox8";
            this.inputBox8.Size = new System.Drawing.Size(43, 50);
            this.inputBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox8.TabIndex = 9;
            this.inputBox8.TabStop = false;
            // 
            // inputBox9
            // 
            this.inputBox9.Location = new System.Drawing.Point(488, 259);
            this.inputBox9.Name = "inputBox9";
            this.inputBox9.Size = new System.Drawing.Size(43, 50);
            this.inputBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox9.TabIndex = 10;
            this.inputBox9.TabStop = false;
            // 
            // inputBox10
            // 
            this.inputBox10.Location = new System.Drawing.Point(537, 259);
            this.inputBox10.Name = "inputBox10";
            this.inputBox10.Size = new System.Drawing.Size(43, 50);
            this.inputBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox10.TabIndex = 11;
            this.inputBox10.TabStop = false;
            // 
            // inputBox11
            // 
            this.inputBox11.Location = new System.Drawing.Point(586, 259);
            this.inputBox11.Name = "inputBox11";
            this.inputBox11.Size = new System.Drawing.Size(43, 50);
            this.inputBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox11.TabIndex = 12;
            this.inputBox11.TabStop = false;
            // 
            // inputBox12
            // 
            this.inputBox12.Location = new System.Drawing.Point(635, 259);
            this.inputBox12.Name = "inputBox12";
            this.inputBox12.Size = new System.Drawing.Size(43, 50);
            this.inputBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.inputBox12.TabIndex = 13;
            this.inputBox12.TabStop = false;
            // 
            // KeyCom
            // 
            this.KeyCom.AutoSize = true;
            this.KeyCom.Location = new System.Drawing.Point(201, 54);
            this.KeyCom.Name = "KeyCom";
            this.KeyCom.Size = new System.Drawing.Size(81, 13);
            this.KeyCom.TabIndex = 28;
            this.KeyCom.Text = "KeyCommander";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(458, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "Enter Name";
            // 
            // name_box
            // 
            this.name_box.Location = new System.Drawing.Point(461, 54);
            this.name_box.Name = "name_box";
            this.name_box.Size = new System.Drawing.Size(100, 20);
            this.name_box.TabIndex = 30;
            // 
            // timer
            // 
            this.timer.AutoSize = true;
            this.timer.Location = new System.Drawing.Point(328, 212);
            this.timer.Name = "timer";
            this.timer.Size = new System.Drawing.Size(18, 13);
            this.timer.TabIndex = 31;
            this.timer.Text = "0s";
            // 
            // points_lbl
            // 
            this.points_lbl.AutoSize = true;
            this.points_lbl.Location = new System.Drawing.Point(402, 212);
            this.points_lbl.Name = "points_lbl";
            this.points_lbl.Size = new System.Drawing.Size(20, 13);
            this.points_lbl.TabIndex = 32;
            this.points_lbl.Text = "0P";
            // 
            // Box12
            // 
            this.Box12.Location = new System.Drawing.Point(635, 134);
            this.Box12.Name = "Box12";
            this.Box12.Size = new System.Drawing.Size(43, 50);
            this.Box12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box12.TabIndex = 44;
            this.Box12.TabStop = false;
            // 
            // Box11
            // 
            this.Box11.Location = new System.Drawing.Point(586, 134);
            this.Box11.Name = "Box11";
            this.Box11.Size = new System.Drawing.Size(43, 50);
            this.Box11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box11.TabIndex = 43;
            this.Box11.TabStop = false;
            // 
            // Box10
            // 
            this.Box10.Location = new System.Drawing.Point(537, 134);
            this.Box10.Name = "Box10";
            this.Box10.Size = new System.Drawing.Size(43, 50);
            this.Box10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box10.TabIndex = 42;
            this.Box10.TabStop = false;
            // 
            // Box9
            // 
            this.Box9.Location = new System.Drawing.Point(488, 134);
            this.Box9.Name = "Box9";
            this.Box9.Size = new System.Drawing.Size(43, 50);
            this.Box9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box9.TabIndex = 41;
            this.Box9.TabStop = false;
            // 
            // Box8
            // 
            this.Box8.Location = new System.Drawing.Point(439, 134);
            this.Box8.Name = "Box8";
            this.Box8.Size = new System.Drawing.Size(43, 50);
            this.Box8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box8.TabIndex = 40;
            this.Box8.TabStop = false;
            // 
            // Box7
            // 
            this.Box7.Location = new System.Drawing.Point(385, 134);
            this.Box7.Name = "Box7";
            this.Box7.Size = new System.Drawing.Size(43, 50);
            this.Box7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box7.TabIndex = 39;
            this.Box7.TabStop = false;
            // 
            // Box6
            // 
            this.Box6.Location = new System.Drawing.Point(336, 134);
            this.Box6.Name = "Box6";
            this.Box6.Size = new System.Drawing.Size(43, 50);
            this.Box6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box6.TabIndex = 38;
            this.Box6.TabStop = false;
            // 
            // Box5
            // 
            this.Box5.Location = new System.Drawing.Point(287, 134);
            this.Box5.Name = "Box5";
            this.Box5.Size = new System.Drawing.Size(43, 50);
            this.Box5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box5.TabIndex = 37;
            this.Box5.TabStop = false;
            // 
            // Box4
            // 
            this.Box4.Location = new System.Drawing.Point(238, 134);
            this.Box4.Name = "Box4";
            this.Box4.Size = new System.Drawing.Size(43, 50);
            this.Box4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box4.TabIndex = 36;
            this.Box4.TabStop = false;
            // 
            // Box3
            // 
            this.Box3.Location = new System.Drawing.Point(189, 134);
            this.Box3.Name = "Box3";
            this.Box3.Size = new System.Drawing.Size(43, 50);
            this.Box3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box3.TabIndex = 35;
            this.Box3.TabStop = false;
            // 
            // Box2
            // 
            this.Box2.Location = new System.Drawing.Point(140, 134);
            this.Box2.Name = "Box2";
            this.Box2.Size = new System.Drawing.Size(43, 50);
            this.Box2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box2.TabIndex = 34;
            this.Box2.TabStop = false;
            // 
            // Box1
            // 
            this.Box1.Location = new System.Drawing.Point(91, 134);
            this.Box1.Name = "Box1";
            this.Box1.Size = new System.Drawing.Size(43, 50);
            this.Box1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Box1.TabIndex = 33;
            this.Box1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(635, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 45;
            this.label1.Text = "label1";
            // 
            // KeyCommander
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Box12);
            this.Controls.Add(this.Box11);
            this.Controls.Add(this.Box10);
            this.Controls.Add(this.Box9);
            this.Controls.Add(this.Box8);
            this.Controls.Add(this.Box7);
            this.Controls.Add(this.Box6);
            this.Controls.Add(this.Box5);
            this.Controls.Add(this.Box4);
            this.Controls.Add(this.Box3);
            this.Controls.Add(this.Box2);
            this.Controls.Add(this.Box1);
            this.Controls.Add(this.points_lbl);
            this.Controls.Add(this.timer);
            this.Controls.Add(this.name_box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.KeyCom);
            this.Controls.Add(this.inputBox12);
            this.Controls.Add(this.inputBox11);
            this.Controls.Add(this.inputBox10);
            this.Controls.Add(this.inputBox9);
            this.Controls.Add(this.inputBox8);
            this.Controls.Add(this.inputBox7);
            this.Controls.Add(this.inputBox6);
            this.Controls.Add(this.inputBox5);
            this.Controls.Add(this.inputBox4);
            this.Controls.Add(this.inputBox3);
            this.Controls.Add(this.inputBox2);
            this.Controls.Add(this.inputBox1);
            this.Controls.Add(this.Results);
            this.Controls.Add(this.startGame);
            this.KeyPreview = true;
            this.Name = "KeyCommander";
            this.Text = "KeyCommander";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyCommander_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.inputBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startGame;
        private System.Windows.Forms.Button Results;
        private System.Windows.Forms.Timer sqtime;
        private System.Windows.Forms.PictureBox inputBox1;
        private System.Windows.Forms.PictureBox inputBox2;
        private System.Windows.Forms.PictureBox inputBox3;
        private System.Windows.Forms.PictureBox inputBox4;
        private System.Windows.Forms.PictureBox inputBox5;
        private System.Windows.Forms.PictureBox inputBox6;
        private System.Windows.Forms.PictureBox inputBox7;
        private System.Windows.Forms.PictureBox inputBox8;
        private System.Windows.Forms.PictureBox inputBox9;
        private System.Windows.Forms.PictureBox inputBox10;
        private System.Windows.Forms.PictureBox inputBox11;
        private System.Windows.Forms.PictureBox inputBox12;
        private System.Windows.Forms.Label KeyCom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox name_box;
        private System.Windows.Forms.Label timer;
        private System.Windows.Forms.Label points_lbl;
        private System.Windows.Forms.PictureBox Box12;
        private System.Windows.Forms.PictureBox Box11;
        private System.Windows.Forms.PictureBox Box10;
        private System.Windows.Forms.PictureBox Box9;
        private System.Windows.Forms.PictureBox Box8;
        private System.Windows.Forms.PictureBox Box7;
        private System.Windows.Forms.PictureBox Box6;
        private System.Windows.Forms.PictureBox Box5;
        private System.Windows.Forms.PictureBox Box4;
        private System.Windows.Forms.PictureBox Box3;
        private System.Windows.Forms.PictureBox Box2;
        private System.Windows.Forms.PictureBox Box1;
        private System.Windows.Forms.Label label1;
    }
}

